﻿-- Logs started at 07.05.2025 21:06:10
[2025-05-07 21:06:10] "Application started"
[2025-05-07 21:06:10] "Showing Telegram channel invitation"
[2025-05-07 21:06:11] "Telegram channel opened successfully"
[2025-05-07 21:06:14] "Exit button clicked"
[2025-05-07 21:06:14] "User attempted to close Disgrace"
