﻿-- Logs started at 19.05.2025 11:05:13
[2025-05-19 11:05:13] "Loaded script: war tycoon.lua"
