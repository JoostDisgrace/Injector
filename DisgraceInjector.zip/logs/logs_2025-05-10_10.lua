﻿-- Logs started at 10.05.2025 11:49:03
[2025-05-10 11:49:03] "Application started"
[2025-05-10 11:49:03] "Showing Telegram channel invitation"
[2025-05-10 11:49:04] "Telegram channel opened successfully"
[2025-05-10 11:49:04] "Loaded script: basketball legends.lua"
[2025-05-10 11:49:16] "Settings panel brought to front"
[2025-05-10 11:49:17] "Editor brought to front"
[2025-05-10 11:49:24] "Exit button clicked"
[2025-05-10 11:49:24] "User attempted to close Disgrace"
