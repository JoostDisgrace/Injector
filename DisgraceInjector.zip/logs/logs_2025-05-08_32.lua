﻿-- Logs started at 08.05.2025 20:22:57
[2025-05-08 20:22:57] "Application started"
[2025-05-08 20:22:57] "Showing Telegram channel invitation"
[2025-05-08 20:22:57] "Telegram channel opened successfully"
[2025-05-08 20:23:15] "Injection button clicked"
[2025-05-08 20:23:21] "Attached  successfully!"
[2025-05-08 20:24:43] "User attempted to close Disgrace"
