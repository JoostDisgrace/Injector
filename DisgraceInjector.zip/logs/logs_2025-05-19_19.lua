﻿-- Logs started at 19.05.2025 11:12:15
[2025-05-19 11:12:15] "Loaded script: war tycoon.lua"
