﻿-- Logs started at 19.05.2025 10:10:46
[2025-05-19 10:10:46] "File loaded from: C:\Users\DAT PC\Documents\war tycoon.lua"
