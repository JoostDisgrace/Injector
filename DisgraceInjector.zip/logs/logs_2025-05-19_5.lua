﻿-- Logs started at 19.05.2025 10:29:27
[2025-05-19 10:29:27] "Loaded script: war tycoon.lua"
