﻿-- Logs started at 08.05.2025 19:40:24
[2025-05-08 19:40:24] "Application started"
[2025-05-08 19:40:24] "Showing Telegram channel invitation"
[2025-05-08 19:40:24] "Telegram channel opened successfully"
[2025-05-08 19:40:31] "Exit button clicked"
[2025-05-08 19:40:31] "User attempted to close Disgrace"
