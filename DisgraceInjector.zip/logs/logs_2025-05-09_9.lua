﻿-- Logs started at 09.05.2025 15:40:59
[2025-05-09 15:40:59] "Application started"
[2025-05-09 15:40:59] "Showing Telegram channel invitation"
[2025-05-09 15:40:59] "Telegram channel opened successfully"
[2025-05-09 15:41:00] "Loaded script: octopus game.lua"
[2025-05-09 15:41:16] "Window minimized"
[2025-05-09 15:42:41] "Exit button clicked"
[2025-05-09 15:42:41] "User attempted to close Disgrace"
