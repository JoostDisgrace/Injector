﻿-- Logs started at 19.05.2025 11:03:42
[2025-05-19 11:03:42] "Loaded script: war tycoon.lua"
