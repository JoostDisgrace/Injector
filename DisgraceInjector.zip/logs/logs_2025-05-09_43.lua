﻿-- Logs started at 09.05.2025 21:55:37
[2025-05-09 21:55:37] "Application started"
[2025-05-09 21:55:37] "Showing Telegram channel invitation"
[2025-05-09 21:55:37] "Telegram channel opened successfully"
[2025-05-09 21:55:37] "Loaded script: basketball legends.lua"
[2025-05-09 21:55:53] "Exit button clicked"
[2025-05-09 21:55:53] "User attempted to close Disgrace"
