﻿-- Logs started at 09.05.2025 21:09:01
[2025-05-09 21:09:01] "Error initializing application: System.IO.FileNotFoundException: Editor files not found at: C:\Users\DAT PC\Downloads\Sources\disgrace injector\disgrace injector\bin\x64\Debug\net9.0-windows\Monaco \index.html
   at disgrace_injector.disgrace.InitializeAsync() in C:\Users\DAT PC\Downloads\Sources\disgrace injector\disgrace injector\Form1.cs:line 181"
[2025-05-09 21:09:24] "Unexpected error during initialization: Editor files not found at: C:\Users\DAT PC\Downloads\Sources\disgrace injector\disgrace injector\bin\x64\Debug\net9.0-windows\Monaco \index.html"
[2025-05-09 21:09:40] "Application started"
[2025-05-09 21:09:40] "Showing Telegram channel invitation"
[2025-05-09 21:09:40] "Telegram channel opened successfully"
[2025-05-09 21:09:40] "Loaded script: octopus game.lua"
[2025-05-09 21:09:45] "Exit button clicked"
[2025-05-09 21:09:45] "User attempted to close Disgrace"
