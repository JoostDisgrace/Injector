﻿-- Logs started at 09.05.2025 16:35:24
[2025-05-09 16:35:24] "Application started"
[2025-05-09 16:35:24] "Showing Telegram channel invitation"
[2025-05-09 16:35:25] "Telegram channel opened successfully"
[2025-05-09 16:35:25] "Loaded script: octopus game.lua"
[2025-05-09 16:35:52] "Settings panel brought to front"
[2025-05-09 16:36:01] "Exit button clicked"
[2025-05-09 16:36:01] "User attempted to close Disgrace"
