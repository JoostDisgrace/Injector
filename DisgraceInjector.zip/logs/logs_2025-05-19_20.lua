﻿-- Logs started at 19.05.2025 11:14:02
[2025-05-19 11:14:02] "Loaded script: war tycoon.lua"
