﻿-- Logs started at 07.05.2025 21:55:24
[2025-05-07 21:55:24] "Application started"
[2025-05-07 21:55:24] "Showing Telegram channel invitation"
[2025-05-07 21:55:24] "Telegram channel opened successfully"
