﻿-- Logs started at 09.05.2025 21:10:55
[2025-05-09 21:10:55] "Application started"
[2025-05-09 21:10:55] "Showing Telegram channel invitation"
[2025-05-09 21:10:55] "Telegram channel opened successfully"
[2025-05-09 21:10:59] "Injection button clicked"
[2025-05-09 21:11:51] "Exit button clicked"
[2025-05-09 21:11:51] "User attempted to close Disgrace"
