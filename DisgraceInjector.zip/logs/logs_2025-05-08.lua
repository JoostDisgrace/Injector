﻿-- Logs started at 08.05.2025 9:38:10
[2025-05-08 09:38:10] "Application started"
[2025-05-08 09:38:10] "Showing Telegram channel invitation"
[2025-05-08 09:38:10] "Telegram channel opened successfully"
