﻿-- Logs started at 10.05.2025 11:45:41
[2025-05-10 11:45:41] "Application started"
[2025-05-10 11:45:41] "Showing Telegram channel invitation"
[2025-05-10 11:45:41] "Telegram channel opened successfully"
[2025-05-10 11:45:41] "Loaded script: basketball legends.lua"
[2025-05-10 11:45:54] "Settings panel brought to front"
[2025-05-10 11:45:57] "Editor brought to front"
[2025-05-10 11:46:31] "Exit button clicked"
[2025-05-10 11:46:31] "User attempted to close Disgrace"
