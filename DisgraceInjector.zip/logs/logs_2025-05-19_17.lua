﻿-- Logs started at 19.05.2025 11:06:09
[2025-05-19 11:06:09] "Loaded script: war tycoon.lua"
