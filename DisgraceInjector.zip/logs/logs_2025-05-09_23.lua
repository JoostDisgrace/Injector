﻿-- Logs started at 09.05.2025 16:54:15
[2025-05-09 16:54:15] "Application started"
[2025-05-09 16:54:15] "Showing Telegram channel invitation"
[2025-05-09 16:54:15] "Telegram channel opened successfully"
[2025-05-09 16:54:15] "Loaded script: octopus game.lua"
[2025-05-09 16:54:25] "Window minimized"
[2025-05-09 16:56:04] "Exit button clicked"
[2025-05-09 16:56:04] "User attempted to close Disgrace"
