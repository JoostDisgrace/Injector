﻿-- Logs started at 08.05.2025 20:36:04
[2025-05-08 20:36:04] "Application started"
[2025-05-08 20:36:04] "Showing Telegram channel invitation"
[2025-05-08 20:36:04] "Telegram channel opened successfully"
[2025-05-08 20:36:18] "Injection button clicked"
