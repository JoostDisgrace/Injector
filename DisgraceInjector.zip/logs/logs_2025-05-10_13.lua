﻿-- Logs started at 10.05.2025 11:51:59
[2025-05-10 11:51:59] "Application started"
[2025-05-10 11:51:59] "Showing Telegram channel invitation"
[2025-05-10 11:51:59] "Telegram channel opened successfully"
[2025-05-10 11:52:14] "Exit button clicked"
[2025-05-10 11:52:14] "User attempted to close Disgrace"
[2025-05-10 11:52:20] "Exit button clicked"
[2025-05-10 11:52:20] "User attempted to close Disgrace"
