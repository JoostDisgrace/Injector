﻿-- Logs started at 08.05.2025 14:09:34
[2025-05-08 14:09:34] "Application started"
[2025-05-08 14:09:34] "Showing Telegram channel invitation"
[2025-05-08 14:09:35] "Telegram channel opened successfully"
[2025-05-08 14:10:38] "Exit button clicked"
[2025-05-08 14:10:38] "User attempted to close Disgrace"
