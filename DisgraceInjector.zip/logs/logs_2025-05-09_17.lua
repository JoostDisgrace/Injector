﻿-- Logs started at 09.05.2025 16:23:42
[2025-05-09 16:23:42] "Application started"
[2025-05-09 16:23:42] "Showing Telegram channel invitation"
[2025-05-09 16:23:43] "Telegram channel opened successfully"
[2025-05-09 16:23:43] "Loaded script: octopus game.lua"
[2025-05-09 16:24:40] "Exit button clicked"
[2025-05-09 16:24:40] "User attempted to close Disgrace"
