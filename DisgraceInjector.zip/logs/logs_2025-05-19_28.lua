﻿-- Logs started at 19.05.2025 11:55:18
[2025-05-19 11:55:18] "Loaded script: war tycoon.lua"
