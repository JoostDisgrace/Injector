﻿-- Logs started at 10.05.2025 11:41:22
[2025-05-10 11:41:22] "Application started"
[2025-05-10 11:41:22] "Showing Telegram channel invitation"
[2025-05-10 11:41:22] "Telegram channel opened successfully"
[2025-05-10 11:41:22] "Loaded script: basketball legends.lua"
[2025-05-10 11:42:24] "Exit button clicked"
[2025-05-10 11:42:24] "User attempted to close Disgrace"
