﻿-- Logs started at 09.05.2025 21:29:08
[2025-05-09 21:29:08] "Application started"
[2025-05-09 21:29:08] "Showing Telegram channel invitation"
[2025-05-09 21:29:08] "Telegram channel opened successfully"
[2025-05-09 21:29:08] "Loaded script: basketball legends.lua"
[2025-05-09 21:29:25] "Exit button clicked"
[2025-05-09 21:29:25] "User attempted to close Disgrace"
