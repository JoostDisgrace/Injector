﻿-- Logs started at 10.05.2025 11:43:12
[2025-05-10 11:43:12] "Application started"
[2025-05-10 11:43:12] "Showing Telegram channel invitation"
[2025-05-10 11:43:12] "Telegram channel opened successfully"
[2025-05-10 11:43:12] "Loaded script: basketball legends.lua"
[2025-05-10 11:43:17] "Injection button clicked"
[2025-05-10 11:43:25] "Exit button clicked"
[2025-05-10 11:43:25] "User attempted to close Disgrace"
