﻿-- Logs started at 07.05.2025 20:45:41
[2025-05-07 20:45:41] "Application started"
[2025-05-07 20:45:41] "Showing Telegram channel invitation"
[2025-05-07 20:45:41] "Telegram channel opened successfully"
[2025-05-07 20:47:26] "Exit button clicked"
[2025-05-07 20:47:26] "User attempted to close Disgrace"
