﻿-- Logs started at 08.05.2025 14:58:03
[2025-05-08 14:58:03] "Application started"
[2025-05-08 14:58:03] "Showing Telegram channel invitation"
[2025-05-08 14:58:03] "Telegram channel opened successfully"
[2025-05-08 14:58:29] "Settings panel brought to front"
[2025-05-08 14:58:30] "Editor brought to front"
[2025-05-08 14:58:32] "Exit button clicked"
[2025-05-08 14:58:32] "User attempted to close Disgrace"
