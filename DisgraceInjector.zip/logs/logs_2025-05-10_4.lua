﻿-- Logs started at 10.05.2025 11:34:15
[2025-05-10 11:34:15] "Application started"
[2025-05-10 11:34:15] "Showing Telegram channel invitation"
[2025-05-10 11:34:15] "Telegram channel opened successfully"
[2025-05-10 11:34:15] "Loaded script: basketball legends.lua"
[2025-05-10 11:35:07] "Settings panel brought to front"
[2025-05-10 11:35:11] "Editor brought to front"
[2025-05-10 11:35:22] "Exit button clicked"
[2025-05-10 11:35:22] "User attempted to close Disgrace"
