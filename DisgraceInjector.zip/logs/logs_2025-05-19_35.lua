﻿-- Logs started at 19.05.2025 12:34:18
[2025-05-19 12:34:18] "Loaded script: babft.lua"
