﻿-- Logs started at 19.05.2025 11:45:08
[2025-05-19 11:45:08] "Loaded script: war tycoon.lua"
[2025-05-19 11:45:25] "Loaded script: counter blox 2.lua"
[2025-05-19 11:45:26] "Loaded script: babft.lua"
