﻿-- Logs started at 19.05.2025 11:54:23
[2025-05-19 11:54:23] "Loaded script: war tycoon.lua"
