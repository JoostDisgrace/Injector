﻿-- Logs started at 08.05.2025 14:10:46
[2025-05-08 14:10:46] "Application started"
[2025-05-08 14:10:46] "Showing Telegram channel invitation"
[2025-05-08 14:10:46] "Telegram channel opened successfully"
[2025-05-08 14:14:04] "Exit button clicked"
[2025-05-08 14:14:04] "User attempted to close Disgrace"
