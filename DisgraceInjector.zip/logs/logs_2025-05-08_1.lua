﻿-- Logs started at 08.05.2025 9:54:15
[2025-05-08 09:54:15] "Application started"
[2025-05-08 09:54:15] "Showing Telegram channel invitation"
[2025-05-08 09:54:15] "Telegram channel opened successfully"
[2025-05-08 09:54:22] "Exit button clicked"
[2025-05-08 09:54:22] "User attempted to close Disgrace"
