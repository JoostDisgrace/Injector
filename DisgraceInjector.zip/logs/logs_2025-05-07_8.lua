﻿-- Logs started at 07.05.2025 21:40:37
[2025-05-07 21:40:37] "Application started"
[2025-05-07 21:40:37] "Showing Telegram channel invitation"
[2025-05-07 21:40:37] "Telegram channel opened successfully"
[2025-05-07 21:40:42] "Exit button clicked"
[2025-05-07 21:40:42] "User attempted to close Disgrace"
