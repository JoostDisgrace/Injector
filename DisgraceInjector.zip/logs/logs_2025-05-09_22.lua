﻿-- Logs started at 09.05.2025 16:52:15
[2025-05-09 16:52:15] "Application started"
[2025-05-09 16:52:15] "Showing Telegram channel invitation"
[2025-05-09 16:52:15] "Telegram channel opened successfully"
[2025-05-09 16:52:16] "Loaded script: octopus game.lua"
[2025-05-09 16:53:02] "Window minimized"
[2025-05-09 16:53:31] "Window minimized"
[2025-05-09 16:54:06] "Exit button clicked"
[2025-05-09 16:54:06] "User attempted to close Disgrace"
