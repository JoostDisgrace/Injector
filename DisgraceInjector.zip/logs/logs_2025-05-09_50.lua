﻿-- Logs started at 09.05.2025 22:24:51
[2025-05-09 22:24:51] "Application started"
[2025-05-09 22:24:51] "Showing Telegram channel invitation"
[2025-05-09 22:24:51] "Telegram channel opened successfully"
[2025-05-09 22:24:52] "Loaded script: basketball legends.lua"
[2025-05-09 22:24:54] "Exit button clicked"
[2025-05-09 22:24:54] "User attempted to close Disgrace"
