﻿-- Logs started at 09.05.2025 15:54:06
[2025-05-09 15:54:06] "Application started"
[2025-05-09 15:54:06] "Showing Telegram channel invitation"
[2025-05-09 15:54:06] "Telegram channel opened successfully"
[2025-05-09 15:54:06] "Loaded script: octopus game.lua"
[2025-05-09 15:54:23] "Window minimized"
[2025-05-09 16:00:57] "Exit button clicked"
[2025-05-09 16:00:57] "User attempted to close Disgrace"
