﻿-- Logs started at 19.05.2025 11:46:38
[2025-05-19 11:46:38] "Loaded script: war tycoon.lua"
