﻿-- Logs started at 09.05.2025 21:54:13
[2025-05-09 21:54:13] "Application started"
[2025-05-09 21:54:13] "Showing Telegram channel invitation"
[2025-05-09 21:54:13] "Telegram channel opened successfully"
[2025-05-09 21:54:13] "Loaded script: basketball legends.lua"
[2025-05-09 21:54:33] "Exit button clicked"
[2025-05-09 21:54:33] "User attempted to close Disgrace"
