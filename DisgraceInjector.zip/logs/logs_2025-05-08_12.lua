﻿-- Logs started at 08.05.2025 14:01:24
[2025-05-08 14:01:24] "Application started"
[2025-05-08 14:01:24] "Showing Telegram channel invitation"
[2025-05-08 14:01:24] "Telegram channel opened successfully"
[2025-05-08 14:04:54] "Window minimized"
[2025-05-08 14:08:36] "Exit button clicked"
[2025-05-08 14:08:36] "User attempted to close Disgrace"
