﻿-- Logs started at 19.05.2025 9:25:19
[2025-05-19 09:25:19] "File loaded from: C:\Users\DAT PC\Documents\entry point.lua"
