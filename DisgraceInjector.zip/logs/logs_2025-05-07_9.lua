﻿-- Logs started at 07.05.2025 21:41:04
[2025-05-07 21:41:04] "Application started"
[2025-05-07 21:41:04] "Showing Telegram channel invitation"
[2025-05-07 21:41:04] "Telegram channel opened successfully"
[2025-05-07 21:41:09] "Window minimized"
[2025-05-07 21:41:45] "Exit button clicked"
[2025-05-07 21:41:45] "User attempted to close Disgrace"
