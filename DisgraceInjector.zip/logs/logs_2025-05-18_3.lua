﻿-- Logs started at 18.05.2025 23:00:56
[2025-05-18 23:00:56] "File loaded from: C:\Users\DAT PC\Documents\counter boblox.lua"
[2025-05-18 23:01:02] "File loaded from: C:\Users\DAT PC\Documents\war tycoon.lua"
