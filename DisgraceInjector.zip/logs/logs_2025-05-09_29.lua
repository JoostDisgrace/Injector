﻿-- Logs started at 09.05.2025 21:10:34
[2025-05-09 21:10:34] "Application started"
[2025-05-09 21:10:34] "Showing Telegram channel invitation"
[2025-05-09 21:10:34] "Telegram channel opened successfully"
[2025-05-09 21:10:49] "User attempted to close Disgrace"
