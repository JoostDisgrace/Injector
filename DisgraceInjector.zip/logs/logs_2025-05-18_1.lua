﻿-- Logs started at 18.05.2025 22:53:08
[2025-05-18 22:53:08] "File loaded from: C:\Users\DAT PC\Documents\mm2.lua"
