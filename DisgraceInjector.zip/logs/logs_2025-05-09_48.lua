﻿-- Logs started at 09.05.2025 22:12:04
[2025-05-09 22:12:04] "Application started"
[2025-05-09 22:12:04] "Showing Telegram channel invitation"
[2025-05-09 22:12:04] "Telegram channel opened successfully"
[2025-05-09 22:12:04] "Loaded script: basketball legends.lua"
[2025-05-09 22:12:26] "Exit button clicked"
[2025-05-09 22:12:26] "User attempted to close Disgrace"
