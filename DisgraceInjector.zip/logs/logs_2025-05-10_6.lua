﻿-- Logs started at 10.05.2025 11:42:28
[2025-05-10 11:42:28] "Application started"
[2025-05-10 11:42:28] "Showing Telegram channel invitation"
[2025-05-10 11:42:28] "Telegram channel opened successfully"
[2025-05-10 11:42:28] "Loaded script: basketball legends.lua"
[2025-05-10 11:42:32] "Exit button clicked"
[2025-05-10 11:42:32] "User attempted to close Disgrace"
