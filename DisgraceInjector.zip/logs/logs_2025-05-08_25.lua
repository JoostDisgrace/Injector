﻿-- Logs started at 08.05.2025 19:58:47
[2025-05-08 19:58:47] "Application started"
[2025-05-08 19:58:47] "Showing Telegram channel invitation"
[2025-05-08 19:58:47] "Telegram channel opened successfully"
[2025-05-08 19:59:32] "Injection button clicked"
[2025-05-08 19:59:36] "Attached  successfully!"
[2025-05-08 20:01:54] "User attempted to close Disgrace"
