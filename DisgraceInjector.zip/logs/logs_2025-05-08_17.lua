﻿-- Logs started at 08.05.2025 14:18:17
[2025-05-08 14:18:17] "Application started"
[2025-05-08 14:18:17] "Showing Telegram channel invitation"
[2025-05-08 14:18:17] "Telegram channel opened successfully"
[2025-05-08 14:19:01] "Exit button clicked"
[2025-05-08 14:19:01] "User attempted to close Disgrace"
