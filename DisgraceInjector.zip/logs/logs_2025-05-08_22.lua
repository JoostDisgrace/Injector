﻿-- Logs started at 08.05.2025 19:32:44
[2025-05-08 19:32:44] "Application started"
[2025-05-08 19:32:44] "Showing Telegram channel invitation"
[2025-05-08 19:32:44] "Telegram channel opened successfully"
[2025-05-08 19:32:52] "Settings panel brought to front"
[2025-05-08 19:32:54] "Editor brought to front"
[2025-05-08 19:33:13] "Exit button clicked"
[2025-05-08 19:33:13] "User attempted to close Disgrace"
