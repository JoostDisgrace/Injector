﻿-- Logs started at 19.05.2025 9:39:07
[2025-05-19 09:39:07] "File loaded from: C:\Users\DAT PC\Documents\counter blox 2.lua"
