﻿-- Logs started at 08.05.2025 13:43:22
[2025-05-08 13:43:22] "Application started"
[2025-05-08 13:43:22] "Showing Telegram channel invitation"
[2025-05-08 13:43:22] "Telegram channel opened successfully"
[2025-05-08 13:44:05] "Exit button clicked"
[2025-05-08 13:44:05] "User attempted to close Disgrace"
