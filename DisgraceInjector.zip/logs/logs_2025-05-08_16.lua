﻿-- Logs started at 08.05.2025 14:17:07
[2025-05-08 14:17:07] "Application started"
[2025-05-08 14:17:07] "Showing Telegram channel invitation"
[2025-05-08 14:17:07] "Telegram channel opened successfully"
[2025-05-08 14:17:27] "Exit button clicked"
[2025-05-08 14:17:27] "User attempted to close Disgrace"
