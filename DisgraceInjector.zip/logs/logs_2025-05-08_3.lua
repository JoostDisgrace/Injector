﻿-- Logs started at 08.05.2025 13:41:04
[2025-05-08 13:41:05] "Application started"
[2025-05-08 13:41:05] "Showing Telegram channel invitation"
[2025-05-08 13:41:05] "Telegram channel opened successfully"
[2025-05-08 13:41:23] "Exit button clicked"
[2025-05-08 13:41:23] "User attempted to close Disgrace"
