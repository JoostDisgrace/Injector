﻿-- Logs started at 19.05.2025 13:02:05
[2025-05-19 13:02:05] "Loaded script: babft.lua"
