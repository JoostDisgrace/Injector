﻿-- Logs started at 09.05.2025 22:00:16
[2025-05-09 22:00:16] "Application started"
[2025-05-09 22:00:16] "Showing Telegram channel invitation"
[2025-05-09 22:00:16] "Telegram channel opened successfully"
[2025-05-09 22:00:16] "Loaded script: basketball legends.lua"
[2025-05-09 22:00:34] "Window minimized"
[2025-05-09 22:07:53] "Exit button clicked"
[2025-05-09 22:07:53] "User attempted to close Disgrace"
