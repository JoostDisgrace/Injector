﻿-- Logs started at 09.05.2025 15:44:08
[2025-05-09 15:44:08] "Application started"
[2025-05-09 15:44:08] "Showing Telegram channel invitation"
[2025-05-09 15:44:09] "Telegram channel opened successfully"
[2025-05-09 15:44:09] "Loaded script: babft.lua"
[2025-05-09 15:44:12] "Loaded script: babft.lua"
[2025-05-09 15:44:14] "Exit button clicked"
[2025-05-09 15:44:14] "User attempted to close Disgrace"
