﻿-- Logs started at 19.05.2025 19:24:09
[2025-05-19 19:24:09] "Loaded script: babft.lua"
[2025-05-19 19:25:12] "Injection button clicked"
[2025-05-19 19:25:15] "Attached  successfully!"
[2025-05-19 19:25:26] "File loaded from: C:\Users\DAT PC\Documents\mm2.lua"
[2025-05-19 19:25:26] "Loaded script: mm2.lua"
[2025-05-19 19:25:33] "Execute button clicked"
[2025-05-19 19:25:47] "Execute button clicked"
