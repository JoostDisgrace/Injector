﻿-- Logs started at 08.05.2025 20:02:01
[2025-05-08 20:02:01] "Application started"
[2025-05-08 20:02:01] "Showing Telegram channel invitation"
[2025-05-08 20:02:02] "Telegram channel opened successfully"
[2025-05-08 20:02:04] "Injection button clicked"
[2025-05-08 20:02:08] "Attached  successfully!"
[2025-05-08 20:02:20] "User attempted to close Disgrace"
