﻿-- Logs started at 10.05.2025 11:43:00
[2025-05-10 11:43:00] "Error initializing application: System.DllNotFoundException: Unable to load DLL 'WebView2Loader.dll' or one of its dependencies: Не найден указанный модуль. (0x8007007E)
   at Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateCoreWebView2EnvironmentWithOptions(String browserExecutableFolder, String userDataFolder, ICoreWebView2EnvironmentOptions options, ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler environment_created_handler)
   at Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(String browserExecutableFolder, String userDataFolder, CoreWebView2EnvironmentOptions options)
   at disgrace_injector.disgrace.InitializeAsync()"
[2025-05-10 11:43:02] "Unexpected error during initialization: Unable to load DLL 'WebView2Loader.dll' or one of its dependencies: Не найден указанный модуль. (0x8007007E)"
[2025-05-10 11:43:03] "Application started"
[2025-05-10 11:43:03] "Showing Telegram channel invitation"
[2025-05-10 11:43:03] "Telegram channel opened successfully"
[2025-05-10 11:43:03] "Error loading script list: Object reference not set to an instance of an object."
[2025-05-10 11:43:06] "Exit button clicked"
[2025-05-10 11:43:06] "User attempted to close Disgrace"
