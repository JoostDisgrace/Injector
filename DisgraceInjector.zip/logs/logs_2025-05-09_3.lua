﻿-- Logs started at 09.05.2025 15:17:45
[2025-05-09 15:17:45] "Application started"
[2025-05-09 15:17:45] "Showing Telegram channel invitation"
[2025-05-09 15:17:45] "Telegram channel opened successfully"
[2025-05-09 15:18:04] "Exit button clicked"
[2025-05-09 15:18:04] "User attempted to close Disgrace"
