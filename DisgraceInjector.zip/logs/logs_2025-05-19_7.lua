﻿-- Logs started at 19.05.2025 10:45:37
[2025-05-19 10:45:37] "Loaded script: war tycoon.lua"
