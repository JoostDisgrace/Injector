﻿-- Logs started at 07.05.2025 20:51:08
[2025-05-07 20:51:08] "Application started"
[2025-05-07 20:51:08] "Showing Telegram channel invitation"
[2025-05-07 20:51:08] "Telegram channel opened successfully"
[2025-05-07 20:51:24] "User attempted to close Disgrace"
