﻿-- Logs started at 19.05.2025 11:53:21
[2025-05-19 11:53:21] "Loaded script: war tycoon.lua"
