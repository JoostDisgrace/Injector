﻿-- Logs started at 09.05.2025 21:12:30
[2025-05-09 21:12:30] "Application started"
[2025-05-09 21:12:30] "Showing Telegram channel invitation"
[2025-05-09 21:12:30] "Telegram channel opened successfully"
[2025-05-09 21:17:04] "Exit button clicked"
[2025-05-09 21:17:04] "User attempted to close Disgrace"
