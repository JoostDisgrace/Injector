﻿-- Logs started at 19.05.2025 10:55:33
[2025-05-19 10:55:33] "Loaded script: war tycoon.lua"
