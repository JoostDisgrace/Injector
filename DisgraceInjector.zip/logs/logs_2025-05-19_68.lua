﻿-- Logs started at 19.05.2025 19:20:52
[2025-05-19 19:20:52] "Loaded script: babft.lua"
[2025-05-19 19:20:59] "Loaded script: counter blox 2.lua"
[2025-05-19 19:20:59] "Loaded script: war tycoon.lua"
[2025-05-19 19:22:37] "Injection button clicked"
[2025-05-19 19:22:40] "Attached  successfully!"
[2025-05-19 19:22:55] "Window set to TopMost"
[2025-05-19 19:23:25] "Execute button clicked"
