﻿-- Logs started at 07.05.2025 21:45:47
[2025-05-07 21:45:47] "Application started"
[2025-05-07 21:45:47] "Showing Telegram channel invitation"
[2025-05-07 21:45:47] "Telegram channel opened successfully"
[2025-05-07 21:45:52] "Exit button clicked"
[2025-05-07 21:45:52] "User attempted to close Disgrace"
