﻿-- Logs started at 08.05.2025 20:34:21
[2025-05-08 20:34:21] "Application started"
[2025-05-08 20:34:21] "Showing Telegram channel invitation"
[2025-05-08 20:34:22] "Telegram channel opened successfully"
[2025-05-08 20:34:43] "Injection button clicked"
