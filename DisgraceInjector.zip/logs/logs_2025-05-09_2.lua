﻿-- Logs started at 09.05.2025 15:14:00
[2025-05-09 15:14:00] "Application started"
[2025-05-09 15:14:00] "Showing Telegram channel invitation"
[2025-05-09 15:14:00] "Telegram channel opened successfully"
[2025-05-09 15:14:08] "Window minimized"
[2025-05-09 15:17:37] "Exit button clicked"
[2025-05-09 15:17:37] "User attempted to close Disgrace"
