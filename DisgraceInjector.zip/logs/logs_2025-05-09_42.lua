﻿-- Logs started at 09.05.2025 21:54:39
[2025-05-09 21:54:39] "Application started"
[2025-05-09 21:54:39] "Showing Telegram channel invitation"
[2025-05-09 21:54:39] "Telegram channel opened successfully"
[2025-05-09 21:54:39] "Loaded script: basketball legends.lua"
[2025-05-09 21:55:09] "Window minimized"
[2025-05-09 21:55:29] "Exit button clicked"
[2025-05-09 21:55:29] "User attempted to close Disgrace"
