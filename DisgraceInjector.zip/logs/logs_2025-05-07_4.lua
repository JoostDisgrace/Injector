﻿-- Logs started at 07.05.2025 21:04:59
[2025-05-07 21:04:59] "Error initializing WebView2: Unable to load DLL 'WebView2Loader.dll' or one of its dependencies: Не найден указанный модуль. (0x8007007E)"
