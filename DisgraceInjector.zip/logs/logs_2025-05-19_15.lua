﻿-- Logs started at 19.05.2025 11:04:29
[2025-05-19 11:04:29] "Loaded script: war tycoon.lua"
