﻿-- Logs started at 09.05.2025 22:20:11
[2025-05-09 22:20:11] "Application started"
[2025-05-09 22:20:11] "Showing Telegram channel invitation"
[2025-05-09 22:20:11] "Telegram channel opened successfully"
[2025-05-09 22:20:11] "Loaded script: basketball legends.lua"
[2025-05-09 22:23:18] "Settings panel brought to front"
[2025-05-09 22:23:21] "Editor brought to front"
[2025-05-09 22:23:44] "Exit button clicked"
[2025-05-09 22:23:44] "User attempted to close Disgrace"
