﻿-- Logs started at 09.05.2025 21:26:49
[2025-05-09 21:26:49] "Application started"
[2025-05-09 21:26:49] "Showing Telegram channel invitation"
[2025-05-09 21:26:49] "Telegram channel opened successfully"
[2025-05-09 21:26:50] "Loaded script: basketball legends.lua"
[2025-05-09 21:27:06] "Exit button clicked"
[2025-05-09 21:27:06] "User attempted to close Disgrace"
