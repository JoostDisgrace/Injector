﻿-- Logs started at 19.05.2025 11:01:27
[2025-05-19 11:01:27] "Loaded script: war tycoon.lua"
