﻿-- Logs started at 08.05.2025 19:41:10
[2025-05-08 19:41:10] "Application started"
[2025-05-08 19:41:10] "Showing Telegram channel invitation"
[2025-05-08 19:41:10] "Telegram channel opened successfully"
[2025-05-08 19:41:29] "Settings panel brought to front"
[2025-05-08 19:41:30] "Editor brought to front"
[2025-05-08 19:41:32] "Exit button clicked"
[2025-05-08 19:41:32] "User attempted to close Disgrace"
