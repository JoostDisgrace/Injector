﻿-- Logs started at 20.05.2025 10:05:03
[2025-05-20 10:05:03] "Loaded script: babft.lua"
[2025-05-20 10:05:15] "Injection button clicked"
[2025-05-20 10:07:28] "Injection button clicked"
[2025-05-20 10:07:32] "Attached  successfully!"
