﻿-- Logs started at 09.05.2025 21:18:36
[2025-05-09 21:18:36] "Application started"
[2025-05-09 21:18:36] "Showing Telegram channel invitation"
[2025-05-09 21:18:37] "Telegram channel opened successfully"
[2025-05-09 21:18:37] "Loaded script: basketball legends.lua"
[2025-05-09 21:18:50] "Settings panel brought to front"
[2025-05-09 21:18:52] "Editor brought to front"
[2025-05-09 21:18:59] "Exit button clicked"
[2025-05-09 21:18:59] "User attempted to close Disgrace"
