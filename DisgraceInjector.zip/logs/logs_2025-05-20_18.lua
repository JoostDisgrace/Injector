﻿-- Logs started at 20.05.2025 20:32:36
[2025-05-20 20:32:36] "Loaded script: babft.lua"
[2025-05-20 20:33:04] "Execute button clicked"
