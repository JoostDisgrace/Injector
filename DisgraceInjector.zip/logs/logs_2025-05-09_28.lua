﻿-- Logs started at 09.05.2025 21:09:50
[2025-05-09 21:09:50] "Error initializing application: System.IO.FileNotFoundException: Editor files not found at: C:\Users\DAT PC\Downloads\Sources\disgrace injector\disgrace injector\bin\x64\Debug\net9.0-windows\Monaco \index.html
   at disgrace_injector.disgrace.InitializeAsync() in C:\Users\DAT PC\Downloads\Sources\disgrace injector\disgrace injector\Form1.cs:line 181"
[2025-05-09 21:09:59] "Unexpected error during initialization: Editor files not found at: C:\Users\DAT PC\Downloads\Sources\disgrace injector\disgrace injector\bin\x64\Debug\net9.0-windows\Monaco \index.html"
