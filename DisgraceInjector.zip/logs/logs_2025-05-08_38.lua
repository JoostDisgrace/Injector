﻿-- Logs started at 08.05.2025 20:42:36
[2025-05-08 20:42:36] "Application started"
[2025-05-08 20:42:36] "Showing Telegram channel invitation"
[2025-05-08 20:42:36] "Telegram channel opened successfully"
[2025-05-08 20:42:55] "Injection button clicked"
[2025-05-08 20:43:06] "Attached  successfully!"
[2025-05-08 20:44:45] "Window minimized"
[2025-05-08 20:45:21] "Exit button clicked"
[2025-05-08 20:45:21] "User attempted to close Disgrace"
