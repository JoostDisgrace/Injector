﻿-- Logs started at 20.05.2025 19:54:24
[2025-05-20 19:54:24] "Loaded script: babft.lua"
[2025-05-20 19:55:06] "Injection button clicked"
[2025-05-20 19:55:09] "Attached  successfully!"
[2025-05-20 19:55:13] "Execute button clicked"
[2025-05-20 19:55:41] "Execute button clicked"
[2025-05-20 19:58:29] "Execute button clicked"
