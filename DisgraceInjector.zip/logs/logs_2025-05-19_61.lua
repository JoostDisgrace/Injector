﻿-- Logs started at 19.05.2025 18:53:31
[2025-05-19 18:53:31] "Loaded script: babft.lua"
[2025-05-19 18:53:43] "Loaded script: counter blox 2.lua"
[2025-05-19 18:53:43] "Loaded script: war tycoon.lua"
[2025-05-19 18:53:44] "Loaded script: babft.lua"
