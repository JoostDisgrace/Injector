﻿-- Logs started at 08.05.2025 13:44:50
[2025-05-08 13:44:50] "Application started"
[2025-05-08 13:44:50] "Showing Telegram channel invitation"
[2025-05-08 13:44:50] "Telegram channel opened successfully"
[2025-05-08 13:45:06] "Exit button clicked"
[2025-05-08 13:45:06] "User attempted to close Disgrace"
