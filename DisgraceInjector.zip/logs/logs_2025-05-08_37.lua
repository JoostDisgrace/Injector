﻿-- Logs started at 08.05.2025 20:40:40
[2025-05-08 20:40:40] "Application started"
[2025-05-08 20:40:40] "Showing Telegram channel invitation"
[2025-05-08 20:40:40] "Telegram channel opened successfully"
[2025-05-08 20:40:57] "Injection button clicked"
[2025-05-08 20:41:03] "Attached  successfully!"
[2025-05-08 20:41:19] "Execute button clicked"
[2025-05-08 20:42:27] "Exit button clicked"
[2025-05-08 20:42:27] "User attempted to close Disgrace"
