﻿-- Logs started at 19.05.2025 19:32:34
[2025-05-19 19:32:34] "Loaded script: babft.lua"
[2025-05-19 19:32:49] "Telegram channel opened successfully"
