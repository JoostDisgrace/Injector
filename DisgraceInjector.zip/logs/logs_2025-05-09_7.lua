﻿-- Logs started at 09.05.2025 15:35:20
[2025-05-09 15:35:20] "Application started"
[2025-05-09 15:35:20] "Showing Telegram channel invitation"
[2025-05-09 15:35:20] "Telegram channel opened successfully"
[2025-05-09 15:35:21] "Loaded script: octopus game.lua"
[2025-05-09 15:35:23] "Loaded script: babft.lua"
[2025-05-09 15:35:27] "Loaded script: octopus game.lua"
[2025-05-09 15:35:36] "Exit button clicked"
[2025-05-09 15:35:36] "User attempted to close Disgrace"
