﻿-- Logs started at 19.05.2025 10:52:59
[2025-05-19 10:52:59] "Loaded script: war tycoon.lua"
