﻿-- Logs started at 07.05.2025 21:05:24
[2025-05-07 21:05:24] "Error initializing WebView2: Unable to load DLL 'WebView2Loader.dll' or one of its dependencies: Не найден указанный модуль. (0x8007007E)"
[2025-05-07 21:05:25] "Application started"
[2025-05-07 21:05:25] "Showing Telegram channel invitation"
[2025-05-07 21:05:26] "Telegram channel opened successfully"
[2025-05-07 21:05:35] "Injection button clicked"
[2025-05-07 21:05:44] "Injection button clicked"
[2025-05-07 21:05:59] "Exit button clicked"
[2025-05-07 21:05:59] "User attempted to close Disgrace"
