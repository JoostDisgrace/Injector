﻿-- Logs started at 09.05.2025 15:38:32
[2025-05-09 15:38:32] "Application started"
[2025-05-09 15:38:32] "Showing Telegram channel invitation"
[2025-05-09 15:38:32] "Telegram channel opened successfully"
[2025-05-09 15:38:32] "Loaded script: octopus game.lua"
[2025-05-09 15:38:42] "Exit button clicked"
[2025-05-09 15:38:42] "User attempted to close Disgrace"
