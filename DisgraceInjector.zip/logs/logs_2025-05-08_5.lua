﻿-- Logs started at 08.05.2025 13:42:47
[2025-05-08 13:42:47] "Application started"
[2025-05-08 13:42:47] "Showing Telegram channel invitation"
[2025-05-08 13:42:47] "Telegram channel opened successfully"
[2025-05-08 13:42:56] "Exit button clicked"
[2025-05-08 13:42:56] "User attempted to close Disgrace"
