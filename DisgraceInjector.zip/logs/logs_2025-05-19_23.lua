﻿-- Logs started at 19.05.2025 11:25:08
[2025-05-19 11:25:08] "Loaded script: war tycoon.lua"
