﻿-- Logs started at 19.05.2025 11:18:31
[2025-05-19 11:18:31] "Loaded script: war tycoon.lua"
