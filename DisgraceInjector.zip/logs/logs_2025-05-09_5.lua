﻿-- Logs started at 09.05.2025 15:26:53
[2025-05-09 15:26:53] "Application started"
[2025-05-09 15:26:53] "Showing Telegram channel invitation"
[2025-05-09 15:26:53] "Telegram channel opened successfully"
[2025-05-09 15:27:04] "File loaded from: C:\Users\DAT PC\Documents\counter boblox.lua"
[2025-05-09 15:27:04] "Loaded script: counter boblox.lua"
[2025-05-09 15:27:19] "Exit button clicked"
[2025-05-09 15:27:19] "User attempted to close Disgrace"
