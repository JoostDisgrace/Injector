﻿-- Logs started at 08.05.2025 13:42:19
[2025-05-08 13:42:19] "Application started"
[2025-05-08 13:42:19] "Showing Telegram channel invitation"
[2025-05-08 13:42:19] "Telegram channel opened successfully"
[2025-05-08 13:42:28] "Exit button clicked"
[2025-05-08 13:42:28] "User attempted to close Disgrace"
