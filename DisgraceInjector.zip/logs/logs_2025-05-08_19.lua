﻿-- Logs started at 08.05.2025 14:54:05
[2025-05-08 14:54:05] "Application started"
[2025-05-08 14:54:05] "Showing Telegram channel invitation"
[2025-05-08 14:54:05] "Telegram channel opened successfully"
[2025-05-08 14:54:11] "Settings panel brought to front"
[2025-05-08 14:54:13] "Editor brought to front"
[2025-05-08 14:55:48] "Exit button clicked"
[2025-05-08 14:55:48] "User attempted to close Disgrace"
