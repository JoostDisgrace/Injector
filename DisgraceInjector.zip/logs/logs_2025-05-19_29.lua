﻿-- Logs started at 19.05.2025 12:01:19
[2025-05-19 12:01:19] "Loaded script: war tycoon.lua"
[2025-05-19 12:01:31] "Loaded script: counter blox 2.lua"
[2025-05-19 12:01:31] "Loaded script: babft.lua"
[2025-05-19 12:01:34] "Loaded script: war tycoon.lua"
[2025-05-19 12:01:34] "Loaded script: war tycoon.lua"
[2025-05-19 12:01:34] "Loaded script: counter blox 2.lua"
[2025-05-19 12:01:35] "Loaded script: babft.lua"
[2025-05-19 12:01:35] "Loaded script: babft.lua"
