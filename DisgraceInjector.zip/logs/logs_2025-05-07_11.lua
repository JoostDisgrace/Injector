﻿-- Logs started at 07.05.2025 21:46:55
[2025-05-07 21:46:55] "Application started"
[2025-05-07 21:46:55] "Showing Telegram channel invitation"
[2025-05-07 21:46:55] "Telegram channel opened successfully"
[2025-05-07 21:47:07] "Injection button clicked"
[2025-05-07 21:47:15] "Execute button clicked"
[2025-05-07 21:47:17] "Exit button clicked"
[2025-05-07 21:47:17] "User attempted to close Disgrace"
