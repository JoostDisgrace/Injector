﻿-- Logs started at 09.05.2025 21:11:55
[2025-05-09 21:11:55] "Application started"
[2025-05-09 21:11:55] "Showing Telegram channel invitation"
[2025-05-09 21:11:55] "Telegram channel opened successfully"
[2025-05-09 21:12:16] "Exit button clicked"
[2025-05-09 21:12:16] "User attempted to close Disgrace"
