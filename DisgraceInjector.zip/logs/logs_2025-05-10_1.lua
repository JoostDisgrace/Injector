﻿-- Logs started at 10.05.2025 11:18:48
[2025-05-10 11:18:48] "Application started"
[2025-05-10 11:18:48] "Showing Telegram channel invitation"
[2025-05-10 11:18:48] "Telegram channel opened successfully"
[2025-05-10 11:18:48] "Loaded script: war tycoon.lua"
[2025-05-10 11:23:41] "Exit button clicked"
[2025-05-10 11:23:41] "User attempted to close Disgrace"
