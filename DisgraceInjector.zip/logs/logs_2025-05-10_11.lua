﻿-- Logs started at 10.05.2025 11:50:02
[2025-05-10 11:50:02] "Application started"
[2025-05-10 11:50:02] "Showing Telegram channel invitation"
[2025-05-10 11:50:02] "Telegram channel opened successfully"
[2025-05-10 11:51:00] "User attempted to close Disgrace"
