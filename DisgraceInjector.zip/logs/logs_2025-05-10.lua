﻿-- Logs started at 10.05.2025 11:10:45
[2025-05-10 11:10:45] "Application started"
[2025-05-10 11:10:45] "Showing Telegram channel invitation"
[2025-05-10 11:10:45] "Telegram channel opened successfully"
[2025-05-10 11:10:45] "Loaded script: war tycoon.lua"
[2025-05-10 11:11:55] "Settings panel brought to front"
[2025-05-10 11:12:03] "Editor brought to front"
[2025-05-10 11:18:43] "Exit button clicked"
[2025-05-10 11:18:43] "User attempted to close Disgrace"
